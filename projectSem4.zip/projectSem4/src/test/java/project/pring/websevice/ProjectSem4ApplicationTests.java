package project.pring.websevice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSem4ApplicationTests {

	@Test
	void contextLoads() {
	}
}
